<?php
header("Content-type:text/html;charset=utf-8");
//服务器获取浏览器ajax传过来的值
$user = $_POST['name'];
$pwd = md5($_POST['pwd']);
//连接数据库，并查询用户名和密码都匹配的数据
$pdo = new PDO("mysql:host=localhost;dbname=yeyiling","root","");
$pdo->query("set names utf8");
$sql="select * from loginuser where username='$user' and password='$pwd'";

$rs = $pdo->query($sql);
if($rs){
    $row = $rs->fetch();
    $loc = $row['locate'];
    session_start();
    $_SESSION["ch_name"] = $row["ch_name"];
    $_SESSION["user_id"] = $row["user_id"];
    if($loc==1||$loc==2){
        echo  json_encode($loc);//响应json编码后的数据
    }else{
        echo json_encode(0);
    }

}


?>