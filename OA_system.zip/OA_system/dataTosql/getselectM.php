<?php
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();
$depidval=$_GET['depidval'];

//$pdo = new PDO("mysql:host=localhost;dbname=yeyiling","root","");
//$pdo->query("set names utf8");

$sql = "select m_name,m_id from manager where m_depid='$depidval'";//ִ��sql���
//$rs = $pdo->query($sql);
$arr = $controller->getdbDate($sql);
//while($data=$rs->fetch()){
//    $arr[] = $data;
//}
echo json_encode($arr);


?>