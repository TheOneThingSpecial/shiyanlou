<?php
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();

$manName = addslashes($_GET["manName"]);//接收ajax传送的数据
$manId = $_GET["manId"];
$manGender = $_GET["manGender"];
$manDepid = $_GET["manDepid"];

//$pdo = new PDO("mysql:host=localhost;dbname=yeyiling","root","");
//$pdo->query("set names utf8");

$sql1 = "select count(*) from manager";
$data1 = $controller->getdbDate($sql1);
if(!empty($data1)){//表非空，则添加，判断前后行数是否一样，一样则返回0添加失败，不一样则返回1添加成功
    $p1 = $data1[0][0];       //添加前的经理表行数

    $sql3 = "select * from manager where m_name='$manName' and m_depid='$manDepid'";
    $data3 = $controller->getdbDate($sql3);
    if(empty($data3)){        //该经理不存在(姓名和所在部门都不一样)，则支持添加
        $sql = "insert into manager (m_id,m_name,m_gender,m_depid) values ('$manId','$manName','$manGender','$manDepid')";//执行sql语句
        $controller->insertDate($sql);
    }
    $sql2 ="select count(*) from manager";
    $data2 = $controller->getdbDate($sql2);
    $p2 = $data2[0][0];       //添加经理后的表行数
    if($p1==$p2){
        echo json_encode(0);
    }else{
        echo json_encode(1);
    }
}else{//表为空，则直接添加，返回1添加成功
    $sql = "insert into manager (m_id,m_name,m_gender,m_depid) values ('$manId','$manName','$manGender','$manDepid')";//执行sql语句
    $controller->insertDate($sql);
    echo json_encode(1);
}



?>