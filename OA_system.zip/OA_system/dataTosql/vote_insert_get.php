<?php
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();
$emid = $_POST["emid"];//接收ajax传送的数据
$list = $_POST["listVal"];

//echo json_encode($list[$i]);exit;
//$vitime = $_GET['vtime'];
$jidu = ceil(date('n')/3);

//$pdo = new PDO("mysql:host=localhost;dbname=yeyiling","root","");
//$pdo->query("set names utf8");

//取经理列表数据，返回二维数组
$sqlm = "select * from manager";//执行sql语句
//$rsm = $pdo->query($sqlm);
//while($arrm=$rsm->fetch()){
//    $arrma[] = $arrm;
//}
$arrma = $controller->getdbDate($sqlm);


$i=0;
$flag=false;

foreach($arrma as $v){
    $mid = $v["m_id"];
    $mdepid = $v["m_depid"];
    $val =  $list[$i]+0;
    ////判断当前时间是否在当前季度内，如果是则不能投票
    $sql1 = "select * from jixiao where em_id='$emid' and ma_id='$mid' ORDER BY time DESC";//执行sql语句
//    $rs = $pdo->query($sql1);
//    while($arr1=$rs->fetch()){
//        $arr[] = $arr1;
//    }
    $arr = $controller->getdbDate($sql1);
    if(empty($arr)){
        $flag=true;
        $sql = "insert into jixiao value ('$emid','$mdepid','$mid','$val',NOW())";//执行sql语句
//        $pdo->query($sql);
        $controller->insertDate($sql);
    }else{
        $p_jidu = ceil((substr($arr[0]['time'], 5, 2)+0) / 3);
//        echo json_encode(substr($arr[0]['time'], 5, 2)+0);
        if ($jidu != $p_jidu) {
            $flag=true;
            $sql = "insert into jixiao value ('$emid','$mdepid','$mid','$val',NOW())";//执行sql语句
//            $pdo->query($sql);
            $controller->insertDate($sql);
        }
    }

    $i+=1;
}
echo json_encode($flag);




//echo json_encode(sizeof($arr));





?>
