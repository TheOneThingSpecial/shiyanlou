<?php
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();
$depname = addslashes($_GET["dname"]);//����ajax���͵�����
$depid = $_GET["did"];

//$pdo = new PDO("mysql:host=localhost;dbname=yeyiling","root","");
//$pdo->query("set names utf8");

$sql = "update department set d_id='$depid',d_name='$depname' where d_id = '$depid'";//ִ��sql���
$controller->updateDate($sql);
echo json_encode(1);
?>