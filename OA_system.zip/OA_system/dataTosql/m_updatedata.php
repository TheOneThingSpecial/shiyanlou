<?php
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();

$manName = addslashes($_GET["mname"]);//����ajax���͵�����
$manId = $_GET["mid"];
$manGender = $_GET["mgender"];
$manDepid = $_GET["mdepid"];

//$pdo = new PDO("mysql:host=localhost;dbname=yeyiling","root","");
//$pdo->query("set names utf8");

$sql = "update manager set m_id='$manId',m_name='$manName',m_gender='$manGender',m_depid='$manDepid' where m_id = '$manId'";//ִ��sql���
$controller->updateDate($sql);
echo json_encode(1);
?>