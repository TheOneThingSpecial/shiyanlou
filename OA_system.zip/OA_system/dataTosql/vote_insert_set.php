<?php
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller  = new controller();
$emid = $_GET['emid'];
//$pdo = new PDO("mysql:host=localhost;dbname=yeyiling","root","");
//$pdo->query("set names utf8");

$sql = "select * from manager";//执行sql语句
//$rs = $pdo->query($sql);
//while($arr1=$rs->fetch()){
//    $arr[] = $arr1;
//}
$arr = $controller->getdbDate($sql);
echo json_encode($arr);
?>
