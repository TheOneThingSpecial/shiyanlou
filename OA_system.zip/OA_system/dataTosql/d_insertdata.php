<?php
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();

$depname = addslashes($_GET["dname"]);//接收ajax传送的数据
//对数据进行转义操作
//echo $depname;exit;

//$depid = $_GET["did"];

//$pdo = new PDO("mysql:host=localhost;dbname=yeyiling","root","");
//$pdo->query("set names utf8");

$sql1="select * from department where d_name='$depname'";
$data1 = $controller->getdbDate($sql1);
if(!empty($data1)){
    $p1 = $data1[0][0];
//echo json_encode($p1);
    if($p1!=null){
        echo json_encode(0);
    }else{
        $sql = "insert into department (d_name) values ('$depname')";//执行sql语句
        $controller->insertDate($sql);
        echo json_encode(1);
    }
}else{
    $sql = "insert into department (d_name) values ('$depname')";//执行sql语句
    $controller->insertDate($sql);
    echo json_encode(1);
}




?>