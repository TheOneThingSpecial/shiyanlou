<?php
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();

$del = $_GET["del"];//����ajax���͵�����

//$pdo = new PDO("mysql:host=localhost;dbname=yeyiling","root","");
//$pdo->query("set names utf8");


$sql = "delete from department where d_id='$del'";//ִ��sql���
$controller->deleteDate($sql);
echo json_encode(1);
?>