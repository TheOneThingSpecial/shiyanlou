<!DOCTYPE html>
<html>
<!--
Description
@author: yunzhi li
@version: 2016/12/9 14:59
          $Id$
-->
<head lang="en">
    <meta charset="UTF-8" />
    <title>infogo考核系统</title>

<!--    <script type="text/javascript" language="javascript" src="./lib/select_user_pwd.js" charset="UTF-8"></script>-->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <script src="./dist/js/jquery.min.js"></script>
    <script src="./dist/js/bootstrap.min.js"></script>
    <script src="./artDialog/jquery.artDialog.js?skin=default"></script><!--引入弹框插件-->
    <link rel="stylesheet" href="./validform/Validform_v5.3.2/demo/css/style.css" type="text/css">
    <link rel="stylesheet" href="./validform/Validform_v5.3.2/demo/css/demo.css" type="text/css">
    <script type="text/javascript" src="./validform/Validform_v5.3.2_min.js"></script>
<!--    <script src="../artDialog-master/lib/jquery-1.10.2.js"></script>-->
    <link rel="stylesheet" href="../artDialog-master/css/ui-dialog.css">
    <script src="../artDialog-master/dist/dialog-min.js"></script>
    <script src="./js/index.js"></script>
</head>
<body style="background-color: #2DA3C5;">


<div class="infogo">
    <h1>杭州盈高科技考核系统</h1>
</div>

<form class="f_login" id="f__login" method="post" action="./match.php">
    <br/>
    <br/>
    <div class="form-group row">
        <label for="name" class="col-lg-2 col-lg-push-1 text-right" style="font-size:18px;font-weight: normal">用户名</label>
        <div class="col-lg-5 col-lg-push-1 text-left"><input  class="form-control" nullmsg="请填写用户名！" sucmsg="用户名验证通过！" type="text"  class="inputxt" value="" datatype="s6-18"  tip="--请输入公司邮箱帐号--"  name="name" id="name"></div>
        <p><span class="Validform_checktip" style="margin-left: 2px;"></span></p>
    </div>

    <div class="form-group row">
        <label for="pwd" class="col-lg-2 col-lg-push-1 text-right" style="font-size:18px;font-weight: normal">密&nbsp;&nbsp;&nbsp;&nbsp;码</label>
        <div class="col-lg-5 col-lg-push-1 text-left"><input class="form-control" nullmsg="请填写密码！" sucmsg="密码验证通过！" type="password" class="inputxt" datatype="*6-18"  name="pwd" id="pwd" ></div>
        <p ><span class="Validform_checktip" style="margin-left: 2px;"></span></p>
    </div>
    <br />
      <input type="submit" value="登录" id="submit" class="btn btn-info btn-xs"><!--onclick="showUserPwd()"-->
      <input type="reset" value="重置" id="reset" class="btn btn-info btn-xs">
</form>
</body>
</html>