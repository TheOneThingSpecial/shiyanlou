<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<!--
Description

@author: yunzhi li
@version: 2016/12/15 11:17
          $Id$
-->
<meta charset="utf-8">
<head>
    <title></title>
    <link rel="stylesheet" href="../css/h_logo.css" type="text/css">
    <script src="../lib/jquery-3.1.1.js"></script>
</head>
<body>
    <form action="upload.php" target="mywin" method="post" enctype="multipart/form-data">
        <p>文件上传</p>
        <p>
            <input type="file" name="img"><br/><span style="font-size: 16px;">仅支持png,gif,jpg格式</span>
        </p>
<!--        <p>-->
<!--            <input type="submit" value="">-->
<!--        </p>-->
    </form>
<!--    <p></p>-->
<!--    <div id="div1">-->
<!--        <img src="" id="imgid"/>-->
<!--    </div>-->
    <iframe name="mywin" frameborder="1" src="" style="display: none;"></iframe>
<script src="../js/h_logo.js"></script>

</body>
</html>