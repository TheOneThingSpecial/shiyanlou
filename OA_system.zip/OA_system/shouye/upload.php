<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "http://www.w3.org/TR/html4/loose.dtd">
<html>
<!--
Description

@author: yunzhi li
@version: 2017/1/10 11:44
          $Id$
-->
<head>
    <title></title>
</head>
<body>


<?php
//print_r($_FILES);//图片文件的基本信息
$type = array('png','jpg','gif');

$src = $_FILES['img']['tmp_name'];//获取选择文件的src路径
$file = $_FILES['img']['name'];//获取图片文件的名称
$name = explode('.',$file);
$ext = array_pop($name);//分割文件，得到数组，获取后缀名
if(in_array($ext,$type)){
    $rename = time().mt_rand().'.'.$ext;//图片文件重命名，防止重名。
    //$rename = 'logo.png';
    $destxt = "../logo/logo.txt";
    $myfile = fopen($destxt, "w") or die("Unable to open file!");
    fwrite($myfile, $rename);
    fclose($myfile);
    $dst = "../logo/".$rename;
    if($_FILES['img']['error']===0){ //提示为0即表示上传成功
        if(move_uploaded_file($src,$dst)){//移动文件从元目录移动到目标目录
//            echo "<script>parent.document.getElementById('imgid').src = '{$dst}';</script>";
//            echo "<script>alert('上传成功，请点击右上角刷新按钮');</script>";
        }
    }
}else{
    echo "<script>alert('图片格式有误');</script>";
}
?>
<script src="../lib/jquery-3.1.1.js"></script>
<script>
//    var dst = "<?php //echo $dst;?>//"
//$(window.parent.parent.parent.frames[0].document).find("#imgl").attr('src',dst);//注意层级
window.parent.parent.parent.frames[0].window.location.reload();


</script>
</body>
</html>






?>