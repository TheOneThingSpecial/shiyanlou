<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "http://www.w3.org/TR/html4/loose.dtd">
<html>
<meta charset="utf-8"/>
<head>
    <title></title>
    <link rel="stylesheet" href="../css/em_h_votedetail.css" type="text/css">
<!--    <script src="../lib/jquery-3.1.1.js"></script>-->
    <link href="../dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <script src="../dist/js/jquery.min.js"></script>
    <script src="../dist/js/bootstrap.min.js"></script>
    <script src="../artDialog/jquery.artDialog.js?skin=default"></script><!--引入弹框插件-->
</head>
<!--
1、连接数据库
2、执行mysql语句
3、将数据放入二维数组中返回
-->
<?php
session_start();
$uid = $_SESSION["user_id"];
$time = $_GET['time'];                //投票时间
$mon = substr($time,5,2);         //投票月份
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();
//if($time!=0){
//    $jixiao = $controller->getdbDate("select * from (jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id) where jixiao.em_id='$uid'and jixiao.time='$time' ORDER BY jixiao.setgrade desc");


switch($mon){
        case 1:$jixiao = $controller->getdbDate("select * from (select * from(jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id)) as v where em_id='$uid' and date_format(time,'%m')<='03'and date_format(time,'%m')>='01' ORDER BY setgrade desc");break;
        case 2:$jixiao = $controller->getdbDate("select * from (select * from(jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id)) as v where em_id='$uid' and date_format(time,'%m')<='03'and date_format(time,'%m')>='01' ORDER BY setgrade desc");break;
        case 3:$jixiao = $controller->getdbDate("select * from (select * from(jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id)) as v where em_id='$uid' and date_format(time,'%m')<='03'and date_format(time,'%m')>='01' ORDER BY setgrade desc");break;
        case 4:$jixiao = $controller->getdbDate("select * from (select * from(jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id)) as v where em_id='$uid' and date_format(time,'%m')<='06'and date_format(time,'%m')>='04' ORDER BY setgrade desc");break;
        case 5:$jixiao = $controller->getdbDate("select * from (select * from(jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id)) as v where em_id='$uid' and date_format(time,'%m')<='06'and date_format(time,'%m')>='04' ORDER BY setgrade desc");break;
        case 6:$jixiao = $controller->getdbDate("select * from (select * from(jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id)) as v where em_id='$uid' and date_format(time,'%m')<='06'and date_format(time,'%m')>='04' ORDER BY setgrade desc");break;
        case 7:$jixiao = $controller->getdbDate("select * from (select * from(jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id)) as v where em_id='$uid' and date_format(time,'%m')<='09'and date_format(time,'%m')>='07' ORDER BY setgrade desc");break;
        case 8:$jixiao = $controller->getdbDate("select * from (select * from(jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id)) as v where em_id='$uid' and date_format(time,'%m')<='09'and date_format(time,'%m')>='07' ORDER BY setgrade desc");break;
        case 9:$jixiao = $controller->getdbDate("select * from (select * from(jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id)) as v where em_id='$uid' and date_format(time,'%m')<='09'and date_format(time,'%m')>='07' ORDER BY setgrade desc");break;
        case 10:$jixiao = $controller->getdbDate("select * from (select * from(jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id)) as v where em_id='$uid' and date_format(time,'%m')<='12'and date_format(time,'%m')>='10' ORDER BY setgrade desc");break;
        case 11:$jixiao = $controller->getdbDate("select * from (select * from(jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id)) as v where em_id='$uid' and date_format(time,'%m')<='12'and date_format(time,'%m')>='10' ORDER BY setgrade desc");break;
        case 12:$jixiao = $controller->getdbDate("select * from (select * from(jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id)) as v where em_id='$uid' and date_format(time,'%m')<='12'and date_format(time,'%m')>='10' ORDER BY setgrade desc");break;
        default:$jixiao = $controller->getdbDate("select * from (jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id) where jixiao.em_id='$uid' ORDER BY jixiao.time desc");break;
    }
//}else{
//    $jixiao = $controller->getdbDate("select * from (jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id left JOIN department on manager.m_depid=department.d_id) where jixiao.em_id='$uid' ORDER BY jixiao.time desc");
//}

?>
<body style="background-color:#CDCDCD;">


<div id="div_2" class="container-fluid"style="background-color: #cdcdcd;">
    <table id="table" class="table table-striped table-hover table-condensed">
        <tr class="success">
            <td>经理</td>
            <td>所在部门</td>
            <td>打分</td>
            <td>投票时间</td>
        </tr>
        <?php foreach($jixiao as $v){?>
            <tr class="active">
                <td><?php echo $v["m_name"];?></td>
                <td><?php echo $v["d_name"];?></td>
                <td><?php echo $v["setgrade"];?></td>
                <td><?php echo $v["time"];?></td>
            </tr>
        <?php }?>
    </table>
</div>

    <script src="../lib/jquery-3.1.1.js" ></script><!--引入jqury-->


        </body>
        </html>
