<!DOCTYPE html>
<html lang="en">
<!--
Description

@author: yunzhi li
@version: 2016/12/14 19:19
          $Id$
-->
<?php
session_start();
?>
<head>
    <meta charset="utf-8" />
    <title>Top</title>
    <link href="../dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <script src="../dist/js/jquery.min.js"></script>
    <script src="../dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/m_Top.css" type="text/css">
    <script src="../js/m_Top.js"></script>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-1 col-md-4 col-sm-6" style="padding-top:20px;"><img src="../logo/<?php $file = file_get_contents("../logo/logo.txt");echo $file;?>" id="imgl"></div>
        <div class="col-lg-3 col-md-4 col-sm-6" style="padding-top:20px;"><h1><?php if($_SESSION["ch_name"]=='admin'){echo "考勤系统管理员界面";}else{echo "考勤系统员工界面";}?></h1></div>
        <div class="col-lg-2 col-lg-push-4 col-md-4 col-sm-6 text-right" style="padding-top:60px;">&nbsp;&nbsp;<img src="../img/people.png" id="imgp">中文名：<?php echo $_SESSION["ch_name"];?></div>
        <div class="col-lg-2 col-lg-push-4 col-md-4 col-sm-6" style="padding-top:60px;"><label id="ptime"></label>&nbsp;&nbsp;&nbsp;<a href="#" title="退出登录" onclick="exitoa();"><img src="../img/exit.png"></a></div>
    </div>
<!--    <div class="row">-->
<!--        -->
<!--    </div>-->
</div>
</body>
</html>