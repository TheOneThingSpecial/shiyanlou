<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "http://www.w3.org/TR/html4/loose.dtd">
<html>
<meta charset="utf-8"/>
<head>
    <title></title>
    <link rel="stylesheet" href="../css/h_manager.css" type="text/css">
<!--    <script src="../lib/jquery-3.1.1.js"></script>-->
    <link href="../dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <script src="../dist/js/jquery.min.js"></script>
    <script src="../dist/js/bootstrap.min.js"></script>
    <script src="../artDialog/jquery.artDialog.js?skin=default"></script><!--引入弹框插件-->
</head>
<!--
1、连接数据库
2、执行mysql语句
3、将数据放入二维数组中返回
-->
<?php
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();
$data = $controller->getdbDate("select * from (manager left join department on manager.m_depid=department.d_id)");//二维数组
$selDep = $controller->getdbDate("select * from department");
?>
<body>

<div id="div_1">
    <div>
        <br/>
        <div class="form-group">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-xs-3 col-sm-3 col-lg-push-3 text-right"><label style="font-weight: normal" for="manaName">经理姓名</label></div>
            <div class="col-lg-3 col-md-3 col-xs-3 col-sm-3 col-lg-push-3"><input type="text"  id="manaName" class="form-control"/></div>
        </div>
        </div>
        <div class="form-group" id="jingliid">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-xs-3 col-sm-3 col-lg-push-3 text-right"><lable for="manaId">经理&nbsp;&nbsp;&nbsp;id</lable></div>
            <div class="col-lg-3 col-md-3 col-xs-3 col-sm-3 col-lg-push-3"><input type="text" id="manaId" class="form-control"/></div>
        </div>
        </div>
        <div class="form-inline">
        <div class="radio" id="sexs">
            &nbsp;&nbsp;选择性别&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <label class="radio-inline disabled"><input type="radio" name="sex" value="男" />男</label>
        </div>&nbsp;&nbsp;&nbsp;
        <div class="radio">
            <label class="radio-inline disabled"><input type="radio" name="sex" value="女"/>女</label>
        </div>
        </div>
        <!-- <input type="text" name="depname" id="depname"/>-->
        <div class="row">
       <div class="col-lg-3 col-md-3 col-xs-3 col-sm-3 col-lg-push-3 text-right"><lable>所属部门</lable></div>
        <div class="col-lg-3 col-md-3 col-xs-3 col-sm-3 col-lg-push-3"><select id="select" class="form-control">
            <?php foreach($selDep as $v){?>
            <option value="<?php echo $v["d_id"];?>"><?php echo $v["d_name"];?></option>
            <?php }?>
        </div>
        </select>
        </div>
        <div id="div_11">
            &nbsp;&nbsp;&nbsp;&nbsp;<input type="button" id="add" value="添加"  class="btn btn-info active"/>
        </div>
    </div>
</div>
<div id="div_2">
    <table id="table" class="table table-striped table-hover table-condensed">
        <tr class="success">
            <td>所属部门</td>
<!--            <td>经理id</td>-->
            <td>经理姓名</td>
            <td>性别</td>
            <td class="del">操作</td>
            <td class="edit">操作</td>
        </tr>
        <?php foreach($data as $v){?>
        <tr class="active">
            <td><?php echo $v["d_name"];?></td>
<!--            <td>--><?php //echo $v["m_id"];?><!--</td>-->
            <td><?php echo $v["m_name"];?></td>
            <td><?php echo $v["m_gender"];?></td>
            <td><a href="#" name="del" id="<?php echo $v["m_id"];?>" onclick="deletem('<?php echo $v["m_id"];?>');" style="color:rgb(7,164,181);text-decoration: none;">删除</a></td>
            <td><a href="#" onclick="updateValm('<?php echo $v["m_id"];?>','<?php echo $v["m_name"];?>','<?php echo $v["m_gender"];?>','<?php echo $v["d_id"];?>');"style="color:rgb(7,164,181);text-decoration: none;">编辑</a></td>

        </tr>
        <?php }?>
    </table>
<!--    <script src="../lib/jquery-3.1.1.js" ></script><!--引入jqury-->
    <script src="../artDialog-master/lib/jquery-1.10.2.js"></script>
    <link rel="stylesheet" href="../artDialog-master/css/ui-dialog.css">
    <script src="../artDialog-master/dist/dialog-min.js"></script>
    <script src="../js/h_manager.js"></script>
</div>
</body>
</html>