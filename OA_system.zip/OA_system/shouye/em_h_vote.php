<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html"
      xmlns="http://www.w3.org/1999/html">
<meta charset="utf-8"/>
<head>
    <title></title>
    <link rel="stylesheet" href="../css/em_h_vote.css" type="text/css">
<!--    <script src="../lib/jquery-3.1.1.js"></script>-->
    <link href="../dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <script src="../dist/js/jquery.min.js"></script>
    <script src="../dist/js/bootstrap.min.js"></script>
    <script src="../artDialog/jquery.artDialog.js?skin=default"></script><!--引入弹框插件-->
</head>
<!--
1、连接数据库
2、执行mysql语句
3、将数据放入二维数组中返回
-->
<?php
session_start();
$uid = $_SESSION["user_id"];
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();
$selMan = $controller->getdbDate("select * from manager");
$jixiao = $controller->getdbDate("select * from jixiao where em_id='$uid' group by MONTH(time) ORDER BY time desc");

?>
<body style="background-color:#CDCDCD;">
<div class="container-fluid">

<div id="div_1">
    <div>
        <p id="p1"><?php echo $_SESSION["user_id"];?></p><br />
        <form method="get" action="a.php">
        <?php foreach($selMan as $v){?>
            <div class="row"  style="border: 1px solid lightseagreen;width:1300px;text-align: center;margin-left: 75px;">
                <div class="col-lg-1 col-lg-push-3" ><label style="font-weight: normal;margin-top:10px;"><?php echo $v['m_name'];?></label></div>
                <div class="radio col-lg-1 col-lg-push-3" style="font-weight: normal;margin-top:10px;"><label><input type="radio" name="<?php echo $v['m_id'];?>" value="10"/>10分</label></div>
                <div class="radio col-lg-1 col-lg-push-3" style="font-weight: normal;margin-top:10px;"><label><input type="radio" name="<?php echo $v['m_id'];?>" value="9"/>9分</label></div>
                <div class="radio col-lg-1 col-lg-push-3" style="font-weight: normal;margin-top:9px;"><label><input type="radio" name="<?php echo $v['m_id'];?>" value="8"/>8分</label></div>
                <div class="radio col-lg-1 col-lg-push-3" style="font-weight: normal;margin-top:8px;"><label><input type="radio" name="<?php echo $v['m_id'];?>" value="7"/>7分</label></div>
                <div class="radio col-lg-1 col-lg-push-3" style="font-weight: normal;margin-top:7px;"><label><input type="radio" name="<?php echo $v['m_id'];?>" value="6"/>6分</label></div>
            </div>

        <?php }?>
        <br/>
        <div id="div_11">
            <input type="button" id="submit" value="投票" class="btn btn-info active"/>
        </div>
        </form>
    </div>
</div>
<div id="div_2">
    <table id="table" class="table table-striped table-hover table-condensed">
        <tr class="success">
<!--            <td>员工 id</td>-->
            <td>投票时间</td>
            <td>投票季度</td>
            <td>操作</td>
        </tr>
        <?php foreach($jixiao as $v){?>
            <tr class="active">
                <!--<td><?php /*echo $v["em_id"];*/?></td>-->
                <td><?php echo $v["time"];?></td>
                <td><?php echo $t=ceil(substr($v["time"],5,2)/3);?></td>
                <td><a href="em_h_votedetail.php?time=<?php echo $v['time'];?>" style="color:rgb(7,164,181);text-decoration: none;">详情</a></td>
           </tr>
       <?php }?>
    </table>
    </div>
<!--    <script src="../lib/jquery-3.1.1.js" ></script><!--引入jqury-->
    <script src="../artDialog-master/lib/jquery-1.10.2.js"></script>
    <link rel="stylesheet" href="../artDialog-master/css/ui-dialog.css">
    <script src="../artDialog-master/dist/dialog-min.js"></script>
    <script src="../js/em_h_vote.js"></script>


    </div>
</div>
</body>
</html>
