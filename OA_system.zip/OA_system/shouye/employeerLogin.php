<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<!--
Description

@author: yunzhi li
@version: 2016/12/14 19:48
          $Id$
-->
<head>
    <title></title>
</head>
<frameset rows="10%,90%" border="0">
    <frame src="./m_Top.php" name="top"/>

    <frameset cols="15%,*">

        <frame src="./em_home.php" name="home"/>
        <frame src="./em_h_vote.php" name="index1"/>

    </frameset>

</frameset>
<body>

</body>
</html>