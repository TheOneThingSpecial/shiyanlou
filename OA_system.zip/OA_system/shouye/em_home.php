<!DOCTYPE html>
<html>
<!--
Description

@author: yunzhi li
@version: 2016/12/14 19:24
          $Id$
-->
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="../css/em_home.css" type="text/css">
</head>

<body>
<div id="div_h1">
    <ul>

        <!--
            作者：1107530849@qq.com
            时间：2014-06-24
            描述：关键点是target属性,需要跟显示页面的name属性一致
        -->
        <li><img src="../img/key.png"><a href="em_h_vote.php" target="index1">投票列表</a></li>
        <li><img src="../img/key.png"><a href="em_h_votedetail.php?time=0" target="index1">投票详情</a></li>
    </ul>

</div>
</body>
</html>
