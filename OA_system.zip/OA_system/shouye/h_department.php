<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<meta charset="utf-8"/>
<head>
    <title></title>
    <link rel="stylesheet" href="../css/h_department.css" type="text/css">
<!--    <script src="../lib/jquery-3.1.1.js"></script>-->
    <link href="../dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <script src="../dist/js/jquery.min.js"></script>
    <script src="../dist/js/bootstrap.min.js"></script>


</head>
<!--
1、连接数据库
2、执行mysql语句
3、将数据放入二维数组中返回
-->
<?php
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();
$data = $controller->getdbDate("select * from department");//二维数组
?>
<body>

<div id="div_1">
    <div>
        <br />
        <br />
        <from>
            <div class="from-group">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-xs-3 col-sm-3 col-lg-push-3 text-right"><label style="font-weight: normal" for="depName">部门名称</label></div>
                    <div class="col-lg-3 col-md-3 col-xs-3 col-sm-3 col-lg-push-3"><input type="text" name="depName" id="depName" class="form-control"/></div>
                    <div id="div_11">
                        <input type="button" id="add" value="添加" class="btn btn-info active"/>
                    </div>
                </div>

            </div>
            <div class="from-group" id="bumenid">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-xs-3 col-sm-3 col-lg-push-3 text-right"><label style="font-weight: normal" for="depId">部门序号</label></div>
                    <div class="col-lg-3 col-md-3 col-xs-3 col-sm-3 col-lg-push-3"><input type="text" name="depId" id="depId" class="form-control"/></div>
                </div>
            </div>
        </from>
    </div>
</div>
<div id="div_2">
    <table id="table" class="table table-striped table-hover table-condensed">
        <tr class="success">
            <td colspan="2">部门名称</td>
<!--            <td colspan="2">部门序号</td>-->
            <td class="del">操作</td>
            <td class="edit">操作</td>
        </tr>
        <?php foreach($data as $v){?>
        <tr class="active">
        <td colspan="2"><?php echo $v["d_name"];?></td>
<!--        <td colspan="2" class="did">--><?php //echo $v["d_id"];?><!--</td>-->
        <td><a href="#" name="del" id="<?php echo $v["d_id"];?>" onclick="deleted('<?php echo $v["d_id"];?>');" style="color:rgb(7,164,181);text-decoration: none;">删除</a></td>
        <td><a href="#" onclick="updateVal('<?php echo $v["d_id"];?>','<?php echo $v["d_name"];?>');" style="color:rgb(7,164,181);text-decoration: none;">编辑</a></td>
        </tr>
        <?php }?>
    </table>
<!--    <script src="../lib/jquery-3.1.1.js" ></script><!--引入jqury-->
<!--    <script src="../artDialog/jquery.artDialog.js?skin=default"></script><!--引入弹框插件-->
    <script src="../artDialog-master/lib/jquery-1.10.2.js"></script>
    <link rel="stylesheet" href="../artDialog-master/css/ui-dialog.css">
    <script src="../artDialog-master/dist/dialog-min.js"></script>
    <script src="../js/h_department.js"></script>
    <div>

    </div>
</div>
</body>
</html>