<!DOCTYPE html>
<html>
<!--
Description

@author: yunzhi li
@version: 2016/12/14 19:24
          $Id$
-->
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="../css/m_home.css" type="text/css">
</head>

<body>
<div id="div_h1">
    <ul>

        <!--
            作者：1107530849@qq.com
            时间：2014-06-24
            描述：关键点是target属性,需要跟显示页面的name属性一致
        -->
        <li><img src="../img/key.png"><a href="h_department.php" target="index1">部门列表</a></li>
        <li><img src="../img/key.png"><a href="h_manager.php" target="index1">经理列表</a></li>
        <li><img src="../img/key.png"><a href="../rank_jixiao/h_rank<?php echo ceil(date('n')/3);?>jidu.php" target="index1">绩效排名</a></li>
        <li><img src="../img/key.png"><a href="../rank_jixiao/jixiaoVote.php?mid=0&&vtime=0&&page=0" target="index1">绩效统计</a></li>
        <li><img src="../img/key.png"><a href="h_logo.php" target="index1">上传系统logo</a></li>
    </ul>

</div>
</body>
</html>
