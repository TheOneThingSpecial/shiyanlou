/**
 * Description
 *
 * @author: yunzhi li
 * @version: 2017/1/5 9:19
 *           $Id$
 */
$("#bumenid").hide();
$("#add").click(function insertd(){//添加部门数据
    depname = $("#depName").val(); //获取文本框的部门名称
    depid = $("#depId").val();     //获取文本框的部门序号
    if(depname==0) {
        var d = dialog({
            content: '添加时不能为空',
            quickClose: true// 点击空白处快速关闭
        });
        d.show(document.getElementById('depName'));
        return false;
    }
//            if(depid==0) {
//                var d = dialog({
//                    content: '添加时不能为空',
//                    quickClose: true// 点击空白处快速关闭
//                });
//                d.show(document.getElementById('depId'));
//                return false;
//            }
    $.ajax({
            url: "../dataTosql/d_insertdata.php",
            type:'get',
            dataType: "json",
            data:{did:depid,dname:depname},
            success: function (param) {
                if(param==0){
                    var d = dialog({
                        title: '消息',
                        content: '该部门已存在！'
                    });
                    d.show();
                    setTimeout(function () {
                        d.close().remove();
                    }, 2000);
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                }else if(param==1){
                    var d = dialog({
                        title: '消息',
                        content: '添加成功！'
                    });
                    d.show();
                    setTimeout(function () {
                        d.close().remove();
                    }, 2000);
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                }
            }
        }
    );
});
function updated(){                        //修改部门数据
    depname = $("#depName").val(); //获取文本框的部门名称
    depid = $("#depId").val();     //获取文本框的部门序号
    $.ajax({
            url: "../dataTosql/d_updatedata.php",

            type:'get',
            dataType: "json",
            data:{did:depid,dname:depname},
            success: function () {
                var d = dialog({
                    title: '消息',
                    content: '修改成功！'
                });
                d.show();
                setTimeout(function () {
                    d.close().remove();
                }, 2000);
                setTimeout(function () {
                    window.location.reload();
                }, 1000);

            }
        }
    );
}
function deleted(id){                 //删除部门数据
    var d = dialog({
        title: '消息',
        content: '您确定要删除吗？',
        ok: function () {
//                    var value = $('#property-returnValue-demo').val();
//                    this.close(value);
//                    this.remove();
//                    delp = id;
            $.ajax({
                url:"../dataTosql/d_deletedata.php",
                type:'get',
                dataType:"json",
                data:{del:id},
                success:function (){
                    var d = dialog({
                        title: '消息',
                        content: '删除成功！'
                    });
                    d.show();
                    setTimeout(function () {
                        d.close().remove();
                    }, 2000);
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                }
            });
        },
        cancel:function(){
            //alert('已取消');
        }

    });
    d.addEventListener('close', function () {
        return false;
    });
    d.show();
//            if(confirm("确定要删除吗？")==false){
//                return false;
//            }
}
function updateVal(did,dname){                              //查看部门数据
    $("#div_11").replaceWith('<div id="div_11">&nbsp;&nbsp;<input type="button" id="edit" onclick="updated();" value="修改" class="btn btn-info active" /></div>');
    $("#depName").val(dname);
    $("#depId").val(did);
}