/**
 * Description
 *
 * @author: yunzhi li
 * @version: 2017/1/5 9:05
 *           $Id$
 */
$(function(){
    $(".f_login").Validform({
        ajaxPost:true,
        tiptype:2,
        callback:function(param){
            if(param == '1'){        //1表示管理员
                window.location.href="./shouye/managerLogin.php";
            }else if(param == '2')  //2表示员工
            {
                window.location.href="./shouye/employeerLogin.php";
            }else if(param==0){
                $("#submit").click(
                    dialog({
                        title:'提示',
                        content:'用户名密码有误，请重新输入！'
                    }).show())
            }
        }
    });

});