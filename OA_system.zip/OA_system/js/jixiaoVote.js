/**
 * Description
 *
 * @author: yunzhi li
 * @version: 2017/1/5 10:17
 *           $Id$
 */
function f_search(emid){
    emname = $("#emname").val();
    if(emname==0){
        var d=dialog({
            content:'请输入！',
            quickClose:true
        });
        d.show(document.getElementById('emname'));
        return false;
    }
    location.href = "jixiaoVoteSearch.php?mid="+emid+"&page=0&emname="+emname;
}