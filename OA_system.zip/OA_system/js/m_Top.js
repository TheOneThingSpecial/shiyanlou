/**
 * Description
 *
 * @author: yunzhi li
 * @version: 2017/1/5 9:15
 *           $Id$
 */
setInterval(function(){      //每秒钟刷新一次，在界面上显示时间
    dobj = new Date();
    year = dobj.getFullYear();
    month = (dobj.getMonth()+1)>9?dobj.getMonth()+1:'0'+(dobj.getMonth()+1);
    day = dobj.getDate()>9?dobj.getDate():'0'+dobj.getDate();
    hour = dobj.getHours()>9?dobj.getHours():'0'+dobj.getHours();
    minute = dobj.getMinutes()>9?dobj.getMinutes():'0'+dobj.getMinutes();
    second = dobj.getSeconds()>9?dobj.getSeconds():'0'+dobj.getSeconds();
    str = year+'-'+month+'-'+day+' '+hour+':'+minute+':'+second;

    pobj = document.getElementById("ptime");
    pobj.innerHTML = str;
},1000);
function exitoa(){
    parent.window.location.href = "http://localhost/yyl/OA_system";
}