/**
 * Description
 *
 * @author: yunzhi li
 * @version: 2017/1/5 9:44
 *           $Id$
 */
$(':file').change(function(){

    $("form").submit();
});