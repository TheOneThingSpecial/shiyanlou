/**
 * Description
 *
 * @author: yunzhi li
 * @version: 2017/1/5 9:26
 *           $Id$
 */
$("#jingliid").hide();
$("#add").click(function insertm(){                              //添加经理表数据
    mananame = $("#manaName").val(); //获取文本框的经理姓名
    manaid = $("#manaId").val();     //获取文本框的经理id
    managender = $("input[name='sex']:checked").val();     //获取单选框性别
    m_depid = $("#select").val();     //获取文本框的经理id
    if(mananame==0) {
        var d = dialog({
            content: '添加时不能为空',
            quickClose: true// 点击空白处快速关闭
        });
        d.show(document.getElementById('manaName'));
        return false;
    }
//            if(manaid==0) {
//                var d = dialog({
//                    content: '添加时不能为空',
//                    quickClose: true// 点击空白处快速关闭
//                });
//                d.show(document.getElementById('manaId'));
//                return false;
//            }
    if(managender==null) {
        var d = dialog({
            content: '添加时不能为空',
            quickClose: true// 点击空白处快速关闭
        });
        d.show(document.getElementById('sexs'));
        return false;
    }
    $.ajax({
            url: "../dataTosql/m_insertdata.php",
            type:'get',
            dataType: "json",
            data:{manName:mananame,manId:manaid,manGender:managender,manDepid:m_depid},
            success: function (param) {
                if(param==0){
                    var d = dialog({
                        title: '消息',
                        content: '该经理id已存在！'
                    });
                    d.show();
                    setTimeout(function () {
                        d.close().remove();
                    }, 2000);
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                }else if(param==1){
                    var d = dialog({
                        title: '消息',
                        content: '添加成功！'
                    });
                    d.show();
                    setTimeout(function () {
                        d.close().remove();
                    }, 2000);
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                }

            }
        }
    );
});
function updatem() {                        //修改经理表数据
    mname = $("#manaName").val();
    mid = $("#manaId").val();
    mgender = $("input[name='sex']:checked").val();
    mdepid = $("#select").val();
    if (mname == 0) {
        var d = dialog({
            content: '修改时不能为空',
            quickClose: true// 点击空白处快速关闭
        });
        d.show(document.getElementById('manaName'));
        return false;
    }
    if (mgender == null) {
        var d = dialog({
            content: '修改时不能为空',
            quickClose: true// 点击空白处快速关闭
        });
        d.show(document.getElementById('sexs'));
        return false;
    }
    $.ajax({
            url: "../dataTosql/m_updatedata.php",
            type: 'get',
            dataType: "json",
            data: {mname: mname, mid: mid, mgender: mgender, mdepid: mdepid},
            success: function () {
                var d = dialog({
                    title: '消息',
                    content: '修改成功！'
                });
                d.show();
                setTimeout(function () {
                    d.close().remove();
                }, 2000);
                setTimeout(function () {
                    window.location.reload();
                }, 1000);

            }
        }
    );
}
function deletem(id){                                       //删除经理表数据
    var d = dialog({
        title: '消息',
        content: '您确定要删除吗？',
        ok: function () {
//                    var value = $('#property-returnValue-demo').val();
//                    this.close(value);
//                    this.remove();
            $.ajax({
                url:"../dataTosql/m_deletedata.php",
                type:'get',
                dataType:"json",
                data:{del:id},
                success:function (){
                    var d = dialog({
                        title: '消息',
                        content: '删除成功！'
                    });
                    d.show();
                    setTimeout(function () {
                        d.close().remove();
                    }, 2000);
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                }
            });
        },
        cancel:function(){
            //alert('已取消');
        }

    });
    d.addEventListener('close', function () {
        return false;
    });
    d.show();
//            if(confirm("确定要删除吗？")==false){
//                return false;
//            }
}
function updateValm(mid,mname,mgender,mdepid){
    $("#div_11").replaceWith('<div id="div_11"><input type="button" id="edit" onclick="updatem();" value="修改" class="btn btn-info active"/></div>');
    $("#manaName").val(mname);
    $("#manaId").val(mid);

    $("input[type=radio]").attr("checked",false);//先置空，若不先置空，则两次改变后将失效
    $("input[type=radio][value="+mgender+"]").attr("checked",true);

    $("#select").val(mdepid);
}