/**
 * Description
 *
 * @author: yunzhi li
 * @version: 2017/1/5 10:28
 *           $Id$
 */

$("p#p1").hide();
$("#submit").click(function insertvote() {          //添加投票
    emid = $("p#p1").html();
    $.ajax({
            url: "../dataTosql/vote_insert_set.php",
            type: 'get',
            dataType: "json",
            data: {emid:emid},
            success: function (param) {
//                        vtime = (new Date()).toLocaleDateString();
//                        alert(vtime);exit;
//                        getM = (new Date()).getMonth()+1;//12月
                var listVal = {};
                for (var i = 0; i < param.length; i++) {
                    vv = param[i]['m_id'];
                    val = $("input:radio[name=" + vv + "]:checked").val();
                    if (val == null) {
                        alert("有未投项!");
                        return false;
                    }
                    listVal[i] = val;
                    employeer = $("p#p1").html();
//                            mid = param[i]['m_id'];
//                            mname = param[i]['m_name'];

                }
                $.ajax({
                    url: "../dataTosql/vote_insert_get.php",
                    type: 'POST',
                    dataType: "json",
                    data: {emid: employeer,listVal:listVal},
                    success: function (param) {
                        if(!param){
                            var d = dialog({
                                title: '消息',
                                content: '不能重复投票！'
                            });
                            d.show();
                            setTimeout(function () {
                                d.close().remove();
                            }, 2000);
                            setTimeout(function () {
                                window.location.reload();
                            }, 2000);
                        }else if(param){
                            var d = dialog({
                                title: '消息',
                                content: '投票成功！'
                            });
                            d.show();
                            setTimeout(function () {
                                d.close().remove();
                            }, 2000);
                            setTimeout(function () {
                                window.location.reload();
                            }, 2000);
                        }

                    }
                });//将所有经理的分数都插入数据库

            }
        }
    );
});