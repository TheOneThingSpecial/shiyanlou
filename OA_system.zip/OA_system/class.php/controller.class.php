<?php
/**
 * Description
 *
 * @author: yunzhi li
 * @version: 2016/12/14 15:43
 *           $Id$
 */
class controller{
    function getdbDate($sql){      //��ȡ���ݿ����ݣ����ض�ά����data
        $model = new model();

        $pdo1 = $model->connect_db();
        $dataArray = $model->executeDate($pdo1,$sql);
//        $view = new views();
//        $view->display($dataArray);
        return $dataArray;
    }
    function insertDate($sql){
        $model = new model();

        $pdo1 = $model->connect_db();
        $model->exeInsert($pdo1,$sql);
        return 1;
    }
    function deleteDate($sql){
        $model = new model();

        $pdo1 = $model->connect_db();
        $model->exeInsert($pdo1,$sql);
        return 1;
    }
    function updateDate($sql){
        $model = new model();

        $pdo1 = $model->connect_db();
        $model->exeInsert($pdo1,$sql);
        return 1;
    }
    /*function show(){                                   //
        $model = new model();
        $data = $model->get();
        $view = new views();
        $view->display($data);
    }
    */
}