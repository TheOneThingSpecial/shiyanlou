<?php
/**
 * Description
 *
 * @author: yunzhi li
 * @version: 2016/12/14 15:34
 *           $Id$
 */
class model
{
    public function get()
    {
        return "hello!";
    }

    public function connect_db()                      //连接数据库
    {
        $pdo = new PDO("mysql:host=localhost;dbname=yeyiling", "root", "");
        $pdo->query("set names utf8");
        return $pdo;
    }
    public function executeDate($pdo1,$sql){           //执行sql语句，取多行数据
        $rs = $pdo1->query($sql);
        $arr = array();
        while($arr1=$rs->fetch()){
            $arr[] = $arr1;
        }
        return $arr;
    }
    public function exeInsert($pdo1,$sql){
        $pdo1->query($sql);
        return 1;
    }
}
