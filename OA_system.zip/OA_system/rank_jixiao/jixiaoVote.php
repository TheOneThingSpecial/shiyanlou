<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "http://www.w3.org/TR/html4/loose.dtd">
<html>
<meta charset="utf-8"/>
<!--
Description

@author: yunzhi li
@version: 2016/12/15 11:16
          $Id$
-->
<?php
/**
 * Description
 *
 * @author: yunzhi li
 * @version: 2016/12/22 8:47
 *           $Id$
 */
$mid = $_GET['mid'];
$vtime1 = $_GET['vtime'];

include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();
//$vtime1 = substr($vtime,5,2)+0;


$perNumber=10; //每页显示的记录数
$page = $_GET['page']+0; //获得当前的页面值

if ($page==0) {
    $page=1;
} //如果没有值,则赋值1



switch($vtime1){
    case 1:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='03'and date_format(time,'%m')>='01')as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='03'and date_format(time,'%m')>='01' ORDER BY setgrade DESC limit $startCount,$perNumber");break;
    case 2:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='03'and date_format(time,'%m')>='01')as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='03'and date_format(time,'%m')>='01' ORDER BY setgrade DESC limit $startCount,$perNumber");break;
    case 3:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='03'and date_format(time,'%m')>='01')as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='03'and date_format(time,'%m')>='01' ORDER BY setgrade DESC limit $startCount,$perNumber");break;

    case 4:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='06'and date_format(time,'%m')>='04')as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='06'and date_format(time,'%m')>='04' ORDER BY setgrade DESC limit $startCount,$perNumber");break;
    case 5:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='06'and date_format(time,'%m')>='04')as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='06'and date_format(time,'%m')>='04' ORDER BY setgrade DESC limit $startCount,$perNumber");break;
    case 6:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='06'and date_format(time,'%m')>='04')as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='06'and date_format(time,'%m')>='04' ORDER BY setgrade DESC limit $startCount,$perNumber");break;

    case 7:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='09'and date_format(time,'%m')>='07')as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='09'and date_format(time,'%m')>='07' ORDER BY setgrade DESC limit $startCount,$perNumber");break;
    case 8:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='09'and date_format(time,'%m')>='07')as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='09'and date_format(time,'%m')>='07' ORDER BY setgrade DESC limit $startCount,$perNumber");break;
    case 9:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='09'and date_format(time,'%m')>='07')as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='09'and date_format(time,'%m')>='07' ORDER BY setgrade DESC limit $startCount,$perNumber");break;
    case 10:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='12'and date_format(time,'%m')>='10')as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='12'and date_format(time,'%m')>='10' ORDER BY setgrade DESC limit $startCount,$perNumber");break;
    case 11:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='12'and date_format(time,'%m')>='10')as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='12'and date_format(time,'%m')>='10' ORDER BY setgrade DESC limit $startCount,$perNumber");break;
    case 12:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='12'and date_format(time,'%m')>='10')as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v WHERE ma_id='$mid' and date_format(time,'%m')<='12'and date_format(time,'%m')>='10' ORDER BY setgrade DESC limit $startCount,$perNumber");break;
    default:$count=$controller->getdbDate("select count(*) from (select user_id,username,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v)as c");
        $totalNumber = $count[0][0];
        $totalPage=ceil($totalNumber/$perNumber); //计算出总页数
        $startCount=($page-1)*$perNumber; //分页开始,根据此方法计算出开始的记录
        $jixiao = $controller->getdbDate("select user_id,ch_name,d_name,m_name,setgrade,time from(select * from (jixiao LEFT JOIN loginuser on jixiao.em_id=loginuser.user_id LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on loginuser.depid=department.d_id))as v ORDER BY setgrade DESC limit $startCount,$perNumber");break;
}


?>

<head>
    <title></title>
    <link rel="stylesheet" href="../css/jixiaoVote.css" type="text/css">
    <link href="../dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <script src="../dist/js/jquery.min.js"></script>
    <script src="../dist/js/bootstrap.min.js"></script>
    <script src="../artDialog/jquery.artDialog.js?skin=default"></script><!--引入弹框插件-->
</head>
    <body>
<div id="div_2">
    <div class="form-group">
    <div class="row">
    <div id="divn" class="col-lg-1">输入员工名</div>
        <div class="input-group col-lg-2">
            <input type="text" name="emname" id="emname" class="form-control">
            <div class="input-group-addon"><span class="glyphicon glyphicon-search" onclick="f_search(<?php echo $_GET['mid'];?>);"></span></div>
        </div>
    </div>
    </div>
    <br />
    <table id="table" class="table table-striped table-hover table-condensed">
        <tr class="success">
<!--            <td>员工id</td>-->
            <td>员工名称</td>
<!--            <td>员工所在部门</td>-->
            <td>经理</td>
            <td>打分</td>
            <td>时间</td>
        </tr>
        <?php foreach($jixiao as $v){?>
        <tr class="active">
<!--            <td>--><?php //echo $v["user_id"];?><!--</td>-->
            <td><?php echo $v["ch_name"];?></td>
<!--            <td>--><?php //echo $v["d_name"];?><!--</td>-->
            <td><?php echo $v["m_name"];?></td>
            <td><?php echo $v["setgrade"];?></td>
            <td><?php echo $v["time"];?></td>
        </tr>
        <?php }?>
    </table>
        <div style="text-align: center;margin-right:10px;">

            <br /><div id="diva">
        <?php

            if ($page != 1) { //页数不等于1
                ?>
                <a href="jixiaoVote.php?mid=<?php echo $mid;?>&&vtime=<?php echo $vtime;?>&&page=<?php echo $page - 1;?>" style="color:#07A4B5">上一页</a> <!--显示上一页-->
                <?php
            }
            for ($i=1;$i<=$totalPage;$i++) {  //循环显示出页面
                ?>
                <a href="jixiaoVote.php?mid=<?php echo $mid;?>&&vtime=<?php echo $vtime;?>&&page=<?php echo $i;?>"style="color:#07A4B5"><?php echo $i ;?></a>
                <?php
            }
            if ($page<$totalPage) { //如果page小于总页数,显示下一页链接
                ?>
                <a href="jixiaoVote.php?mid=<?php echo $mid;?>&&vtime=<?php echo $vtime;?>&&page=<?php echo $page + 1;?>"style="color:#07A4B5">下一页</a>
                <?php
            }
        ?>
                <?php echo "&nbsp;&nbsp;&nbsp;共".$totalPage."页";?>
            </div>
        </div>


<!--<script src="../lib/jquery-3.1.1.js" ></script><!--引入jqury-->
    <script src="../artDialog-master/lib/jquery-1.10.2.js"></script>
    <link rel="stylesheet" href="../artDialog-master/css/ui-dialog.css">
    <script src="../artDialog-master/dist/dialog-min.js"></script>
    <script src="../js/jixiaoVote.js"></script>


</body>
</html>

