<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "http://www.w3.org/TR/html4/loose.dtd">
<html>
<meta charset="utf-8"/>
<head>
    <title></title>
    <link rel="stylesheet" href="../css/h_rankjidu.css" type="text/css">
<!--    <script src="../lib/jquery-3.1.1.js"></script>-->
    <link href="../dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <script src="../dist/js/jquery.min.js"></script>
    <script src="../dist/js/bootstrap.min.js"></script>
    <script src="../artDialog/jquery.artDialog.js?skin=default"></script><!--引入弹框插件-->
</head>
<!--
1、连接数据库
2、执行mysql语句
3、将数据放入二维数组中返回
-->
<?php
session_start();
$uid = $_SESSION["user_id"];
include_once("../class.php/model.class.php");
include_once("../class.php/controller.class.php");
$controller = new controller();
$jixiao = $controller->getdbDate("select ma_id,sum(setgrade) as grade,time,m_name,d_name from (select ma_id,setgrade,time,m_name,d_name from (jixiao LEFT JOIN manager on jixiao.ma_id=manager.m_id LEFT JOIN department on manager.m_depid=department.d_id) where date_format(time,'%m')<='03'and date_format(time,'%m')>='01')as g GROUP BY ma_id order by grade DESC ");
$i = 0;
//print_r($jixiao);
?>
<body>


<div id="div_2">
    <div class="diva">
        <a href="./h_rank1jidu.php"><img src="../img/click.png" >第一季度</a><a href="./h_rank2jidu.php"><img src="../img/click.png"style="color:rgb(7,164,181);text-decoration: none;">第二季度</a><a href="./h_rank3jidu.php"><img src="../img/click.png"style="color:rgb(7,164,181);text-decoration: none;">第三季度</a><a href="./h_rank4jidu.php"><img src="../img/click.png"style="color:rgb(7,164,181);text-decoration: none;">第四季度</a>
    </div><br />
    <div id="divh"><h1>第一季度排名：</h1></div><br/>
    <table id="table" class="table table-striped table-hover table-condensed">
        <tr class="success">
<!--            <td>经理id</td>-->
            <td>经理名称</td>
            <td>所在部门</td>
            <td>总得分</td>
            <td>排名</td>
        </tr>
        <?php foreach($jixiao as $v){?>
            <tr class="active">
<!--                <td>--><?php //echo $v["ma_id"];?><!--</td>-->
                <td><?php echo $v["m_name"];?></td>
                <td><?php echo $v["d_name"];?></td>
                <td><a href="./jixiaoVote.php?mid=<?php echo $v["ma_id"];?>&vtime=3&page=0" title="点击查看详情" style="color:green;text-decoration: none;"><?php echo $v["grade"];?></a></td>
                <td><?php echo $i+=1;?></td>
            </tr>
        <?php }?>
    </table>
    <script src="../lib/jquery-3.1.1.js" ></script><!--引入jqury-->
</body>
</html>
