/*
Navicat MySQL Data Transfer

Source Server         : 172.0.0.1
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : yeyiling

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2017-01-10 11:02:41
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `d_id` int(11) NOT NULL AUTO_INCREMENT,
  `d_name` varchar(255) NOT NULL DEFAULT '' COMMENT '部门名称',
  PRIMARY KEY (`d_id`),
  UNIQUE KEY `d_didsuoyin` (`d_id`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES ('8', '研发部');
INSERT INTO `department` VALUES ('9', '测试部');
INSERT INTO `department` VALUES ('10', '财务部');
INSERT INTO `department` VALUES ('11', '行政部');
INSERT INTO `department` VALUES ('14', '财务部');

-- ----------------------------
-- Table structure for jixiao
-- ----------------------------
DROP TABLE IF EXISTS `jixiao`;
CREATE TABLE `jixiao` (
  `em_id` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `ma_id` int(11) NOT NULL,
  `setgrade` int(11) NOT NULL,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jixiao
-- ----------------------------
INSERT INTO `jixiao` VALUES ('2', '8', '4', '10', '2016-09-04 17:35:47');
INSERT INTO `jixiao` VALUES ('2', '9', '5', '9', '2016-09-04 17:35:47');
INSERT INTO `jixiao` VALUES ('2', '10', '6', '8', '2016-09-04 17:35:47');
INSERT INTO `jixiao` VALUES ('2', '11', '7', '7', '2016-09-04 17:35:47');
INSERT INTO `jixiao` VALUES ('2', '8', '4', '9', '2016-12-05 10:34:09');
INSERT INTO `jixiao` VALUES ('2', '9', '5', '8', '2016-12-05 10:34:09');
INSERT INTO `jixiao` VALUES ('2', '10', '6', '9', '2016-12-05 10:34:10');
INSERT INTO `jixiao` VALUES ('2', '11', '7', '10', '2016-12-05 10:34:10');
INSERT INTO `jixiao` VALUES ('2', '8', '4', '10', '2016-04-05 10:47:52');
INSERT INTO `jixiao` VALUES ('2', '9', '5', '9', '2016-04-05 10:47:52');
INSERT INTO `jixiao` VALUES ('2', '10', '6', '8', '2016-04-05 10:47:52');
INSERT INTO `jixiao` VALUES ('2', '11', '7', '7', '2016-04-05 10:47:52');
INSERT INTO `jixiao` VALUES ('3', '8', '4', '10', '2016-09-05 14:21:37');
INSERT INTO `jixiao` VALUES ('3', '9', '5', '10', '2016-09-05 14:21:37');
INSERT INTO `jixiao` VALUES ('3', '10', '6', '10', '2016-09-05 14:21:37');
INSERT INTO `jixiao` VALUES ('3', '11', '7', '10', '2016-09-05 14:21:37');
INSERT INTO `jixiao` VALUES ('2', '8', '4', '10', '2017-01-10 11:01:02');
INSERT INTO `jixiao` VALUES ('2', '9', '5', '9', '2017-01-10 11:01:03');
INSERT INTO `jixiao` VALUES ('2', '10', '6', '8', '2017-01-10 11:01:03');
INSERT INTO `jixiao` VALUES ('2', '11', '7', '8', '2017-01-10 11:01:03');

-- ----------------------------
-- Table structure for loginuser
-- ----------------------------
DROP TABLE IF EXISTS `loginuser`;
CREATE TABLE `loginuser` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET latin1 NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 NOT NULL,
  `ch_name` varchar(255) NOT NULL,
  `locate` int(11) NOT NULL,
  `depid` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of loginuser
-- ----------------------------
INSERT INTO `loginuser` VALUES ('3', 'bbbbbb', 'd27d320c27c3033b7883347d8beca317', '员工b', '2', '1');
INSERT INTO `loginuser` VALUES ('1', 'admining', '1bbd886460827015e5d605ed44252251', 'admin', '1', '1');
INSERT INTO `loginuser` VALUES ('2', 'aaaaaa', 'bae5e3208a3c700e3db642b6631e95b9', '员工a', '2', '1');

-- ----------------------------
-- Table structure for manager
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager` (
  `m_id` int(11) NOT NULL AUTO_INCREMENT,
  `m_name` varchar(255) NOT NULL,
  `m_gender` varchar(10) DEFAULT NULL,
  `m_depid` int(11) DEFAULT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of manager
-- ----------------------------
INSERT INTO `manager` VALUES ('4', '经理一', '男', '8');
INSERT INTO `manager` VALUES ('5', '经理二', '男', '9');
INSERT INTO `manager` VALUES ('6', '经理三', '女', '10');
INSERT INTO `manager` VALUES ('7', '经理四', '女', '11');

-- ----------------------------
-- Event structure for ye
-- ----------------------------
DROP EVENT IF EXISTS `ye`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` EVENT `ye` ON SCHEDULE AT '2016-12-19 16:11:48' ON COMPLETION NOT PRESERVE ENABLE DO SELECT m_name FROM manager where m_depid=1004
;;
DELIMITER ;
